import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddPropertyComponent } from './add-property/add-property.component';
import { ListSellerPropertiesComponent } from './list-seller-properties/list-seller-properties.component';
import { LoginComponent } from './login/login.component';
import { SellerHomeComponent } from './seller-home/seller-home.component';
import { BuyerHomeComponent } from './buyer-home/buyer-home.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path:'addProperty', component: AddPropertyComponent },
  { path: 'listSellerProperty', component: ListSellerPropertiesComponent },
  { path: 'sellerHome', component: SellerHomeComponent },
  { path: 'buyerHome', component: BuyerHomeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
