import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListSellerPropertiesComponent } from './list-seller-properties.component';

describe('ListSellerPropertiesComponent', () => {
  let component: ListSellerPropertiesComponent;
  let fixture: ComponentFixture<ListSellerPropertiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListSellerPropertiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListSellerPropertiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
