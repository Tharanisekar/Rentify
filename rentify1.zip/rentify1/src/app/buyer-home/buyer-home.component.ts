import { Component, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community'; 

@Component({
  selector: 'app-buyer-home',
  templateUrl: './buyer-home.component.html',
  styleUrls: ['./buyer-home.component.css']
})
export class BuyerHomeComponent implements OnInit {
  constructor() { }

  // Column Definitions: Defines the columns to be displayed.
 colDefs: ColDef[] = [
  { field: "place" },
  { field: "area" },
  { field: "bedrooms" },
  { field: "hospitals" },
  { field: "price"},
  { field: "seller"}
];

  rowData = [
    { place: "Chennai", area: "Nungmbkkam", bedrooms: "2", hospitals: "Availble", price: "54,00,000", seller: "George Antony" },  
    { place: "Banglore", area: "IT City", bedrooms: "3", hospitals: "Availble", price: "80,00,000", seller: "AVG Construction" },  
    { place: "Chennai", area: "Teynmpet", bedrooms: "2", hospitals: "Not Availble", price: "65,00,000", seller: "Surekha homes" },    
  ];

  
  ngOnInit(): void {
  }
}
